# Diamonds Data Exploration

## Dataset

The data consists of information about bike riders,made in Bike-sharing system in San Francisco during Feb 2019.
In addition,In this dataset there is 183412 records(rides) and 16 attributes(features). It contains 4646 different bikes and the duratin time is between 85444sec (24 hours) and 61sec (1 minute). Most of the values are numeric values. 


## Summary of Findings

I recognized there is a big difference between the member types , most of them are subscriber.Also the female are half number of male members. I discover the timing of rides bikes, I create new columns that seperate the days and hours.I focused on the duration feature and its relations with the gender and member type. I see the customer spent more time than the subscriber! despite of the subscriber members are more than costomers by 14,000. Moreover, female spend more time than male even that the number of male are more than female but the different is slight between gender and duration time.I observe that on Sunday female are taking more time with bikes whereas male are taking more time on Saturday.Also, on Sunday and Saturday there is an obviouse increased in both customer and subscriber for the duration time.



## Key Insights for Presentation

I keep only the most important figures in the presentation.I started by talking about the dataset and the first visualization was about the members information then i got deeply.
